/* $Log: registers.h,v $
 * Revision 1.1  1995/09/22  17:34:36  mcc
 * Initial revision
 *
 *
 * Keeps track of register usage 
 */

#define FUTREG %l5
#define IDREG %l6
#define EXPRESSREG %l6
#define TBL_REG %l7
