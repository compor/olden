#ifndef DEBUG_H
#define DEBUG_H

void printfnl(/*FlowNodeList fnl*/);
void printupdl(/*UpdateList updl*/);
void debug0 (/* CallFlowGraph cfg */);
void debug1 (/* CallFlowGraph cfg, Vector updlv*/);
void debug2 (/* LrsList lrs, int *count */);
#endif
