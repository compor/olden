#include "c.h"
extern Interface sparcInterface;
Interface *interfaces[] = {
	&sparcInterface,
	0,0,0,0
};
