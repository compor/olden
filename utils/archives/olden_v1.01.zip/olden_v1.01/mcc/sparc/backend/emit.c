static int junk;
