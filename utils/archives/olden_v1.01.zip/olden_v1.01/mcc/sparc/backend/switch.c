main()
{
  int i;

  switch(i) {
    case 0:
      i=3;
      break;
    case 2:
      i=3;
      break;
    case 4:
      i=3;
      break;
  }
  dummy();
}
